package com.nsh.userinterface;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


/**
 * Created by ${user} on 09/05/2018.
 */
public class LoginActivity extends AppCompatActivity {
    EditText username,password;
    Button login;
    TextView show,forgotpassword,createaccount;


    public void onCreate (Bundle SaveInstanceState)
    {
        super.onCreate(SaveInstanceState);
        setContentView(R.layout.login_relative);

        username = (EditText) findViewById(R.id.etUsername);
        password = (EditText) findViewById(R.id.etPassword);
        show = (TextView) findViewById(R.id.tvshow);
        show = (TextView) findViewById(R.id.tvshow);
        forgotpassword = (TextView) findViewById(R.id.tvForgot);


        password.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (hasWindowFocus()) {
                    show.setVisibility(View.VISIBLE);
                    show.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            //handle click tulisan show/hide
                            if (show.getText().toString().equals("show")) {
                                password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                                show.setText("hide");
                            } else {
                                password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                                show.setText("show");
                            }
                        }
                    });
                }

            }
        });

    }
}
