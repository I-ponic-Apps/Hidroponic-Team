package com.nsh.userinterface;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by ${user} on 19/05/2018.
 */
public class LoginActivity1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_relative_togle);
    }
}
