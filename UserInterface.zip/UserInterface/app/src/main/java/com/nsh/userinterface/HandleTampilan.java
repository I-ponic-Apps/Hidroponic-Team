package com.nsh.userinterface;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by ${user} on 24/05/2018.
 */
public class HandleTampilan extends AppCompatActivity {

    EditText username,password;
    Button login;
    TextView creatuser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showlogin();

    }

    private void showlogin() {

        setContentView(R.layout.login_relative_togle);

        username = (EditText) findViewById(R.id.etUsername);
        password = (EditText) findViewById(R.id.etPassword);
        login = (Button) findViewById(R.id.btnlogin);
        creatuser = (TextView) findViewById(R.id.tvcreatAccount);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // jika password "admin" makan tampilkan menu utama
                if (password.getText().toString().equals("admin")) {
                    showmenutama();
                } else {
                    Toast.makeText(HandleTampilan.this,"salah password",Toast.LENGTH_SHORT).show();
                }
            }
        });

        creatuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showregisteruser();
            }
        });
    }

    private void showregisteruser() {
        setContentView(R.layout.registeruser);

    }

    private void showmenutama() {
        setContentView(R.layout.activity_menu_utama);
    }
}
